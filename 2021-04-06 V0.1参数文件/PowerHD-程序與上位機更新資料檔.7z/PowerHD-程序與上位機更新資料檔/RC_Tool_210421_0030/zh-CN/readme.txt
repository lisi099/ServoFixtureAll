1. This APP is named RC_Tool.
2. RC_Tool_200902_0027 更改高低電壓保護上限20V、10V
3. RC_Tool_200902_0027 更改中心點範圍下限600us
