/******************** (C) COPYRIGHT 2016 ********************


***************************************************************/
#ifndef _MenuAPP_H_BAB
#define _MenuAPP_H_BAB

#include "Menu.h"

extern struct PAGE mainPage;

#endif
