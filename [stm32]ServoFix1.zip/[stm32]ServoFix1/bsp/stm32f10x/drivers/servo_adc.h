/******************** (C) COPYRIGHT 2016 ********************

***************************************************************/
#ifndef _SADC_H_
#define _SADC_H_

#include "stm32f10x.h"

void adc_configration(void);
uint8_t get_servo_state(void );

#endif
