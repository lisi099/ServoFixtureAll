/******************** (C) COPYRIGHT 2016 ********************


***************************************************************/
#ifndef STM32_CRC32_H
#define	STM32_CRC32_H

#include "stm32f10x.h"

uint32_t stm32_crc32( uint32_t *pBuf, uint16_t nSize );

void test_prog(void);



#endif 
